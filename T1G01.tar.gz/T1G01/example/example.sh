./balcao example 20 &
./balcao example 30 &
./balcao example 10 &
sleep 1
./ger_cl example 100 &
sleep 5
./balcao example 15 &
sleep 1
./ger_cl example 15 &
sleep 5
./balcao example 15 &
./balcao example 5 &
sleep 1
./ger_cl example 300
